package com.demo.app.services;

import java.util.Optional;

import com.demo.app.models.entities.Producto;

public interface IProductoService {
	Producto save(Producto producto);
	Optional<Producto> findById(Long id);
}
