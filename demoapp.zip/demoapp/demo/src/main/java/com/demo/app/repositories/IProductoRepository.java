package com.demo.app.repositories;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.demo.app.models.entities.Producto;

@Repository
public interface IProductoRepository extends CrudRepository<Producto, Long> {

}
