package com.demo.app.services;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.demo.app.models.entities.Producto;
import com.demo.app.repositories.IProductoRepository;

@Service
public class ProductoServiceImpl implements IProductoService {

	@Autowired private IProductoRepository productoRepository;
	
	@Override
	@Transactional
	public Producto save(Producto producto) {
		return productoRepository.save(producto);
	}
	
	@Override
	@Transactional(readOnly = true)
	public Optional<Producto> findById(Long id) {		
		return productoRepository.findById(id);
	}
}
