package com.demo.app.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ProductoDto {
	private Long id;	
	private String name;
	private byte[] data; 
}
