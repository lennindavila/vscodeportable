package com.demo.app.controllers;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.demo.app.dto.ProductoDto;
import com.demo.app.encryption.Decryptor;
import com.demo.app.encryption.Encryptor;
import com.demo.app.models.entities.Producto;
import com.demo.app.services.IProductoService;

@RestController
@RequestMapping("/api/Product")
public class ProductoController {

	@Autowired private IProductoService productoService;
/*
	@GetMapping("/get/{id}")
	public ResponseEntity<?> show(@PathVariable Long id) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException{
		Optional<Producto> productoOptional = productoService.findById(id);
		if(productoOptional.isPresent()) {
	         ProductoDto producto = new ProductoDto();			 
			 producto.setName(productoOptional.get().getName());
			 producto.setCategory(productoOptional.get().getCategory());
			 producto.setDescription(productoOptional.get().getDescription());
			 //producto.setData(dencrypt(new String(productoOptional.get().getData())));
			 String data = dencrypt(new String(productoOptional.get().getData()));
			 //String data = new String(productoOptional.get().getData());			 
			 producto.setData(data);
			 producto.setId(productoOptional.get().getId());			
			Optional<ProductoDto> productoDtoOptional = Optional.of(producto);
			System.out.println(data);
			return ResponseEntity.ok(productoDtoOptional.orElseThrow());
		}
		return ResponseEntity.notFound().build();
	}
	*/
	
	@GetMapping("/{id}")
	public ResponseEntity<?> show(@PathVariable Long id) throws InterruptedException {
		Optional<Producto> productoOptional = productoService.findById(id);
		if(productoOptional.isPresent()) {
	         ProductoDto producto = new ProductoDto();			 
			 producto.setName(dencrypt(productoOptional.get().getName()));
			 byte[] arrBytes = productoOptional.get().getData();
			 producto.setData(arrBytes);			
			 producto.setId(productoOptional.get().getId());
			 
			 String directoryOut = "D:\\Development\\udemy\\Spring3-react\\demoapp\\demo\\src\\main\\resources\\out\\";
			 String directoryOutraw = "D:\\Development\\udemy\\Spring3-react\\demoapp\\demo\\src\\main\\resources\\outraw\\";
			 
			 final File file = new File(directoryOut, producto.getName());
			 try {
				FileUtils.writeByteArrayToFile(file, arrBytes);
			} catch (IOException e) {				
				e.printStackTrace();
			}
			Thread.sleep(100); 
			Decryptor de = Decryptor.getDecrypter(false);
			
			File encr = new File(directoryOut);	
			File encrraw = new File(directoryOutraw);
			de.decrypt(encr, encrraw);
			 
			Optional<ProductoDto> productoDtoOptional = Optional.of(producto);			
			return ResponseEntity.ok(productoDtoOptional.orElseThrow());
		}
		return ResponseEntity.notFound().build();
	}
	
	@PostMapping("/")
	@ResponseStatus(HttpStatus.CREATED)
	public ResponseEntity<?> create(@RequestBody Producto producto) {		
		String spt = System.getProperty("file.separator");		
		String directory = "D:\\Development\\udemy\\Spring3-react\\demoapp\\demo\\src\\main\\resources\\data\\";
		//directory = directory.replace(directory,spt);		
		System.out.println("processing" + directory);
		
		Encryptor en = Encryptor.getEncrypter(false);
		//Decryptor de = Decryptor.getDecrypter(true);			
		
		File origin = new File(directory);
		File encr = new File(directory + "encr");			
		en.encrypt(origin, encr);
		
		try {			
			List<Path> pathFileNames = null;		
	        try (Stream<Path> walk = Files.walk(Paths.get(directory + "encr"))) {
	        	pathFileNames = walk
	                    .filter(Files::isRegularFile)
	                    .filter(p -> p.getFileName().toString().endsWith(".txt"))
	                    .collect(Collectors.toList());
	        }catch (IOException e) {			
	        	System.out.println(e.toString());
			}	
	        


	        
	        
	        if(pathFileNames != null && !pathFileNames.isEmpty()) {	        	
	        	for(Path pathFile:pathFileNames) {	        		
	        		File file = pathFile.toFile();
	        		byte[] arrbytes = Files.readAllBytes(pathFile);
	        		String filename = file.getName();
	        		System.out.println(filename);
	        		try {	        			
        				producto = new Producto();        				
        				producto.setName(encrypt(filename));
        				producto.setData(arrbytes);        				
        				productoService.save(producto);
    					Thread.sleep(100);
					} catch (Exception e) {					
						System.out.println(e.toString());
					}
	        	}
	        }
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		return null;//ResponseEntity.status(HttpStatus.CREATED).body(productoService.save(producto));
	}
	
	
	/*
	@GetMapping("/{category}")
	@ResponseStatus(HttpStatus.CREATED)
	public ResponseEntity<?> create(@PathVariable String category) {
		Producto producto = null;
		String spt = System.getProperty("file.separator");		
		String directory = "D:\\Development\\udemy\\Spring3-react\\demoapp\\demo\\src\\main\\resources\\data\\";
		//directory = directory.replace(directory,spt);		
		System.out.println("processing" + directory);
		try {			
			List<Path> pathFileNames = null;		
	        try (Stream<Path> walk = Files.walk(Paths.get(directory))) {
	        	pathFileNames = walk
	                    .filter(Files::isRegularFile)
	                    .filter(p -> p.getFileName().toString().endsWith(".java") || p.getFileName().toString().endsWith(".txt") || p.getFileName().toString().endsWith(".properties")|| p.getFileName().toString().endsWith(".yml") || p.getFileName().toString().endsWith(".pom"))
	                    .collect(Collectors.toList());
	        }catch (IOException e) {			
	        	System.out.println(e.toString());
			}		
	        
	        if(pathFileNames != null && !pathFileNames.isEmpty()) {	        	
	        	for(Path pathFile:pathFileNames) {	        		
	        		File file = pathFile.toFile();
	        		BufferedReader br = null;        		
	        		StringBuilder sb = new StringBuilder();
	        		String line;
	        		String filename = file.getName();
					try {						
						br = new BufferedReader(new FileReader(file));					
						while((line = br.readLine())!=null) {							
							sb.append(line);sb.append(System.getProperty("line.separator"));
						}						
					} catch (IOException e) {
						System.out.println(e.toString());
					}finally {
						if(br!=null)
							try {
								br.close();
							} catch (IOException e) {
								System.out.println(e.toString());
							}
					}
	        		
	        		try {	        			
	        			
	        			if(!sb.toString().isEmpty()) {
	        				producto = new Producto();
	        				producto.setCategory(category);
	        				producto.setName(filename);
	        				//producto.setDescription(sb.toString());
	        				producto.setData(encrypt(sb.toString()).getBytes("UTF8"));
	        				//producto.setData(sb.toString().getBytes("UTF8"));
	        				productoService.save(producto);
	    					Thread.sleep(100);	    					
	        			}
					} catch (Exception e) {					
						System.out.println(e.toString());
					}
	        	}
	        }
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		return null;//ResponseEntity.status(HttpStatus.CREATED).body(productoService.save(producto));
	}*/
	
	private String encrypt(String toEncrypt) {
		int key = 5;
		StringBuilder sb = new StringBuilder();
		char[] chars = toEncrypt.toCharArray();
		for(char c: chars) {
			c+=key;
			sb.append(c);
		}
		return sb.toString();
	}
	
	private String dencrypt(String toDencrypt) {
		int key = 5;
		StringBuilder sb = new StringBuilder();
		char[] chars = toDencrypt.toCharArray();
		for(char c: chars) {
			c-=key;
			sb.append(c);
		}
		return sb.toString();
	}
	
}
